import java.io.IOException;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class Multiply {

    public static class MatrixMapper extends Mapper<LongWritable, Text, Text, Text> {
        public void map(LongWritable key, Text value, Context context)
                throws IOException, InterruptedException {
            String line = value.toString();
            String[] tokens = line.split(",");
            if (tokens.length == 4) {
                String matrix = tokens[0];
                int i = Integer.parseInt(tokens[1]);
                int j = Integer.parseInt(tokens[2]);
                double val = Double.parseDouble(tokens[3]);
                if (matrix.equals("M")) {
                    for (int k = 0; k < 2; k++) {
                        context.write(new Text(i + "," + k),
                                new Text("M," + j + "," + val));
                    }
                } else {
                    for (int r = 0; r < 2; r++) {
                        context.write(new Text(r + "," + j),
                                new Text("N," + i + "," + val));
                    }
                }
            }
        }
    }

    public static class MatrixReducer extends Reducer<Text, Text, Text, Text> {
        public void reduce(Text key, Iterable<Text> values, Context context)
                throws IOException, InterruptedException {
            double[] M = new double[100];
            double[] N = new double[100];
            for (Text val : values) {
                String[] parts = val.toString().split(",");
                int j = Integer.parseInt(parts[1]);
                double v = Double.parseDouble(parts[2]);
                if (parts[0].equals("M")) {
                    M[j] = v;
                } else {
                    N[j] = v;
                }
            }
            double sum = 0;
            for (int j = 0; j < 100; j++) {
                sum += M[j] * N[j];
            }
            context.write(key, new Text(String.valueOf(sum)));
        }
    }

    public static void main(String[] args) throws Exception {
        Configuration conf = new Configuration();
        Job job = Job.getInstance(conf, "MatrixMultiply");
        job.setJarByClass(Multiply.class);
        job.setMapperClass(MatrixMapper.class);
        job.setReducerClass(MatrixReducer.class);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(Text.class);
        FileInputFormat.addInputPath(job, new Path(args[0]));
        FileOutputFormat.setOutputPath(job, new Path(args[1]));
        System.exit(job.waitForCompletion(true) ? 0 : 1);
    }
}
